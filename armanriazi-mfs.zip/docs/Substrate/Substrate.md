- [[Polkadot]]
The Substrate framework provides a robust and flexible WebSocket API allowing connections to the Blockchain to be established by its clients: NFT wallets, Marketplaces, and other programs.

