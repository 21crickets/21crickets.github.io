---
keywords:  MFS ArmanRiazi Music NFT Blockchain White COO
feature:  paper
author: "Arman Riazi"
title: "Whitepaper"
---


![knowledge Graph](./assets/foam.JPG){ width="800" height="600" align=center }

---

> **MFS: a music NFT decentralized platform**

> *As merry as a mars cricket*

> **Play, Mix, Own, Govern, Earn, Self-releasing,Blanket licensing, Co-Owned, M2E, and Pay as you go TRXs**

---

> NOTICE OF CONFIDENTIALITY([Terms and Conditions](Concern_Legal/Agreement_Legal.md))
Case studies, comparisons, statistics, research, and recommendations are provided “AS IS” and intended for informational purposes only and should not be relied upon for operational, marketing, legal, technical, tax, financial, or other advice. AramisTech . neither makes any warranty or representation as to the completeness or accuracy of the information within this document, nor assumes any liability or responsibility that may result from reliance on such information. The Information contained herein is not intended as investment or legal advice, and readers are encouraged to seek the advice of a competent professional where such advice is required. All of details of papers were registered. The paper that you are reading is not a final version, so it is possible that some sections will have minor changes.

> MFS is the short name of the platform, and it is going to be  mentioned  in the final version of the paper.

---

# Project outline

[TOC]

# Abstract
Nowadays, with the development of technology, we observe an increase in the number of users that use streaming music or podcast services.
Whether you’re a singer, artist, labeler, composer, investor, or simply interested in the blockchain space, there is something new for everyone in the platform. A platform that helps you protect, publish, and monetize your music, while offering transparency and insights on reach, performance, and earnings. The MFS suite of apps consists of various solutions tailored to specific needs. Browse our website to read more about all the features, and feel welcome to register your free account. MFS is the swiss army knife for any music professional.
For the music industry, AI technology is more like a thread than a benefit. e.g., deepfake vocal synthesisers, which make a singer's voice sound like that of a famous artist. Who knows, maybe in the near future we will have a tool called MusicGPT!
At present, there is an opportunity for technology companies and the music industry to avoid repeating past mistakes by considering new technologies, and blockchain is the only solution for making legislation with democracy. 
The proposed work has an engineering journey to reach lucrative revenue streams with non-fungible assets. Unlike any other music distribution platform out there, we also allow our users to distribute music to innovative new outlets. By effortlessly creating NFT collections of your release catalogue, you can enter the world of "Web3", unlock revolutionary ways to engage with fans, and tap into new income streams.

Keywords: NFT, Music, Audio, DApp, Musical sophistication, Active engagement, Blanket licensing

---

# Introduction

## Blockchain
Blockchain, which is a technology for building distributed ledgers that provide an immutable log of transactions recorded in a distributed network, has become prominent recently as the underlying technology of cryptocurrencies and is revolutionizing data storage and processing in computer network systems[^15].
Blockchain-agnostic protocols enable cross-blockchain or cross-chain communication between arbitrary distributed ledger technologies[^16].

## What is an NFT?
Like cryptocurrencies, NFTs are issued on a blockchain, and are used to designate ownership of a certain asset.
Unlike cryptocurrency, NFTs are not fungible, meaning each NFT is unique and not interchangeable with another NFT. For the first time, content on the internet in the form of an NFT can be definitively owned by a specific person independent of a centralized intermediary, and this is unlocking exciting opportunities for digital commerce and engagement[^6].


## Unique Network
Unique Network blockchain in the Polkadot ecosystem can be seen as a foundation for standards and good practices serving for any software that uses or relates to NFT. The core components of Unique blockchain are[^1]:

1.  Token Pallets that handle NFTs, RTFs, and Fungible tokens
2.  EVM/Ethereum Smart Contracts


---

# Problem statement

## Have you heard about the phenomenon of the AI music generator?

This phenomenon has copyright owners rightfully concerned, as AI [music generator](./AI/music_generator.md) outputs are veritable collages of fine-grained sound recording samples[^17].
Therefore, one solution is to establish a blanket licensing apparatus for AI music generator training and output. AI developers—as well as other unforeseen parties looking to use numerous works in the future would have a one-stop shop for securing the rights to any works included under the blanket license. This model has been a longstanding practice in the music publishing industry, which utilizes blanket licensing to grant public performance permissions to various users on behalf of hundreds of thousands of authors[^17].

## Royalty Settlement

Existing streaming services must pay royalties for both digital copy and performance rights,but it is not easy to settle the profits properly that go to artist due to lack of transparency. Due to the difficulty of identification, 25% of the total royalties incurred by streaming services will not be paid[^3].

### Sales Profit
Due to the current distribution structure involving various brokers, the distribution of profits to artists has not been properly paid[^3].

- [ ] High fees for streaming services
Streaming services charge 15-40% of royalties to users in the name of usage fees. Due to the high cost, users refuse to use streaming services and obtain music through other methods such as pirated copies[^3].

- [ ] Geographic difficulties preventing entry into new markets
It is difficult for one singer to enter another country’s market, especially Asian artist’s entry into the American and European markets which is vey rare. Even if the singer is successful in Asian markets, it is hard to guarantee the success in fandom formation by entering new markets[^3].


## Project Vision/Objectives

- [x] Establish an ecosystem of Blockchain payment platform for the fastest way to meet World-Genres in the world without regional restriction.
- [x] Create streaming networks where artists can communicate directly with their fans and easily making profits, and it becomes the most preferred music service-oriented in the world.
- [x] Support the growing aspirations and self-creating activities of artists who are ahead of debut competitors.
- [x] Reduce the broker’s revenue share in the entertainment business revenue structure and build an environment where MFS Token can be used as the best payment method.
- [x] Development and deployment of music LCL, NFT EEC.
- [x] Proposed NFT platform can imitate functions of traditional finance and NFTs.
- [x] Working on roadmap continually.

---

# Background

## Streaming Music On Blockchain
The global entertainment market is expected to grow to about $2 trillion by 2021. In 2018, the music streaming market reached nearly $274 million. In addition, 41% of Internet users in Korea have registered for streaming services, and it is far higher than other countries.
Recently, streaming services which increasingly have improved user convenience have emerged as the most accessible segment in the music market today. For groups of artists performing independently, streaming services is becoming a foothold that creating new types of revenue and moving away from geographic constraints to provide a wide range of audiences with their music. The most important thing is that artists also can improve their skills constantly through these services[^3].

## Smart Contract

Smart Contracts have benefits and considerations in three area includes: digital Identity, Records, financial Trade and so on[^8].

## Non-Fungible

NFTs are created for unlocking new commerce and engagement opportunities with identify the NFT use case.

### Fan Engagement
NFTs can be much more than a collectible or piece of art, and savvy brands are recognizing that the most successful and long-term-relevant NFTs will be ones that have ongoing value and utility. For example, NFTs can better connect fans to their favorite teams or brands by offering voting rights to team decisions, access to exclusive offers, and the ability to earn rewards[^6].

### Customer Relationship Management
Unlike physical goods, NFTs are trackable so it can be possible to see what wallet address they reside in. NFTs can open unique segmentation and engagement strategies based on trackable factors related to the NFTs owned/purchased.This might include the types of NFTs owned, the quantity owned, or the duration they’ve been held[^6].

### New Potential Revenue Streams
Because NFTs enable digital scarcity, brands can sell exclusive, limited digital goods. Unlike physical goods, NFTs can include a smart contract that codes in a royalty percentage designated by the content creator. As such, subsequent sales or auctions of the NFT can generate revenue for the original NFT creator, providing an ongoing potential revenue stream as it is sold or auctioned[^6].

### Collectibles
The digital scarcity that NFTs enable is a natural NFT for collectibles or assets whose value is dependent on there being limited supply. Some of the earliest NFT use cases include CryptoKitties3 and CryptoPunks4 (10,000 unique pixelated characters), with individual CryptoPunk NFTs like Covid Alien selling for $11.75 million5. More recently, popular brands are creating NFT-based collectibles, like NBA Top Shot moments, which are digital basketball cards, but instead of static images, these NFTs contain video highlight moments from NBA games[^6].

### Art
NFTs enable artists to sell their work in its natural form factor as opposed to having to print and sell pieces of art. Additionally, unlike with physical art, the artist can receive revenue upon secondary sales or auctions, thereby ensuring they are recognized for their original creations in subsequent transactions. NFT marketplaces devoted to art-based NFTs, such as Nifty Gateway, sold/auctioned over $100M of digital art in March 2021[^6].

### Re-fungible and Fungible Modes
Re-fungibility is an important step towards building real life models of ownership rights. Often a unique item may be owned by multiple entities in different proportions. The examples of such shared ownership are abundant: Timeshares, co-ownership of art, fractional car ownership, etc. For that purpose Unique Network provides the special mode of Collection: Re-Fungible. The Re-fungible token can be minted and then partially transferred to multiple owners.  
Fungible collection mode is targeted at the same set of use cases as ERC-20 tokens: Any non-unique and divisible resource can be represented as a Fungible token. While these use cases are not the prime focus of Unique Network, many applications need this functionality in parallel to the NFT the examples include: Non-unique game resources (such as game money),rating points in applications with social networking capabilities, voting tokens, etc.[^1].


## Consensus and Tokenomics
The Unique Network use the Relay chain consensus, as any Polkadot parachain does, and off-chain mechanisms for Collator incentivization, which is important for decentralization, prevention of censorship attack [26], and improving the user experience due to reducing node latency for client responses[^1].

### Unique Token
Unique Token is the Unique Network token that is used for several purposes[^1]:

1. Transaction rate limiting and DDoS protection in form of transaction fees.
2. Network Services
3. Application data storage rent
4. Advanced features of the network
6. In-app payments through payable smart contract methods
7. App promotion program
8. Paid Rate Limits


## Ownership

The application developer would create the collection and become its owner. [Ownership](Collection_Management/ownership.md) of collection means the full authority over all of its properties and NFTs, including the capacity to destroy the tokens and the collection or give up this authority by transferring the ownership to an address with an unknown private key[^1].

### Operating NFTs
Once the collection is created, its owner can mint tokens that belong to this collection. The minting process is an atomic operation of creating an NFT item, setting this item’s immutable metadata and its owner[^1].

## Standards

The Interchain NFT and Metadata Standardization conducted extensive research of NFT token and their Metadata standards. Unique Network aims to comply with this interchain standard and deliver the network protocol that is applicable to and able to describe a wide range of NFT formats known in order to prewire the NFT interoperability for most if not all known NFT standards, which is explained in detail further[^1].

## Interoperability

Another important feature for existing Ethereum users will be emulation of ERC-721, ERC-20, and other Ethereum standards through RPC calls. These RPC endpoints will enable transparent use of native Unique Network capabilities in Ethereum tools in the same manner as Frontier, i.e. Metamask, Truffle, Web3 libraries, etc. The dApp developers and publishers will be able to seamlessly convert their user bases to Unique with zero learning curve for their users[^1].
Furthermore, the off-chain service can be an additional factor that limits the performance. For off-chain integration, the REST API can be utilized to pass the data to be computed to the outside. However, the REST API will also have certain limitations from a performance perspective.Therefore, alternative integration techniques such as gRPC can be used[^10].

## Fee

Unique Network is going to offer several gas [fee](/DEFI/fee.md) models for its users in order to provide as much flexibility as possible to adapt to miscellaneous marketing strategies of application developers and remove UX friction for the newcomers.
The gas fee model is configured separately for each Collection or a smart contract. Every Collection and smart contract has a fee model assigned to it, which determines how its transactions are paid, and the developer can choose the fee model that better suits their application[^1].
Initially the fee model is configured to a default one and can be updated later at any time and as many times as needed.Currently there are two models implemented: The default “User paid fees” model when the transaction sender pays all gas fees, and the “Pay as you go” model when collection or smart contract owners enable sponsoring for certain transaction types for their users[^1].

### Layers
1. Off-chain community
2. Off-chain development
3. On-chain protocol
   
### Dimensions
1. Roles
2. Incentives
3. Membership
4. Communication
5. Decision Making
6. Format and Context

## DAO
It is usually encapsulated in a set of rules and procedures that regulate conduct of participants in a system. Moving to more decentralized forms of governance, ideally performed on-chain, requires modifying corporate governance processes to fit the idiosyncrasies of blockchains.
In the DeFi and blockchain space, governance, decision-making and operations are typically performed through [DAOs](./DAO/DAO.md).
The BG framework, defining the governance structure of a blockchain as a combination between six governance dimensions, and three governance layers[^19].

<figure markdown>
![DAO](./assets/DAO.JPG){ width="600" height="500" align=center }
<figcaption>Fig 1. DAO[15]</figcaption>
</figure>

## Royalty Management

### When I buy music rights through Royal, what do I get?
When you invest in songs or albums on [Royal](./Royalty_Management/Royalty_Management.md), you get a token representing a percentage of the music’s streaming rights, plus extras. You earn royalties alongside the artist and get paid when they do.
Artists choose what percentage of the song's royalties to drop. They can also attach extras like fan experiences, exclusive tracks, merch, and more—it's all up to them[^4].
### How do I buy a token during a drop?
During a drop, you can buy a token through Royal’s website with a credit card. Before you buy, you’ll be able to see the percentage of ownership per token tier, the extras attached, and information about pricing[^4].
### If you get a token during a drop, it will appear on your Royal dashboard. Missed out on a drop? 
You can buy a token on our music rights marketplace.
Create a free Royal account to receive email notifications about upcoming drops. You can also follow us on social media to keep up with the latest releases[^4].
### How do I claim streaming royalties?
Once you buy a token, your royalties start accruing as the song, EP, or album streams on platforms like Spotify and Apple Music.
You get paid your portion of the royalties when the artist gets paid. The time to payout will vary depending on the artist—on average, payouts happen every 6 months—and we’ll notify you when royalties become available to claim.
Once available, you’ll claim your royalties in your Royal dashboard by transferring funds to another crypto wallet[^4].

### Can I sell my token?
Yes, you can list your token for sale any time on royal.
One exciting part of purchasing music rights is that these assets may appreciate—artist and song popularity, token demand, extras, and more can all play a role in secondary pricing.
Once you sell your token, royalty payouts and unclaimed extras will go to the new token owner[^4].


## Label Management

[Label Services](Label_Management/Label_Management.md) are a fundamental building block of our more robust peer-to-peer platform. This deployment will give access to creative services, playlist pitching, PR services, and advertising for artists and labels on the platform[^2].
It is our intention to build this within Circle’s USDC ecosystem. The advantages of using USDC to transact include removing volatility for crypto payments, allows Unchained Music to accept Credit, Debit, Bank Transfers, and Bank Wires, and hedges against potential stablecoin regulation in the United States by working with the most reputable company issuing a centralized stablecoin today[^2].
Future iterations of the label services platform will allow the Unchained Music token to be used for discounts on these services.[^2]
During this initial deployment we will start to deploy our V1 smart-contracts, which will be built with the intention to allow other service providers, musicians, and other creatives to operate within the peer-to-peer platform upon launch in 2024.[^2]

## Properties

### Metadata Schemas
One important property of a collection is the Off-chain [Schema](Collection_Properties/schema.md). This schema describes the metadata that is associated with each token and can be accessed by the token ID. It can be an image or a more complex and structured data. For additional protection of token authenticity, the off-chain metadata hash can be recorded in the immutable token metadata. Besides the off-chain schema, it is possible to set the similar schemas for mutable and immutable NFT metadata that are stored on-chain. The main purpose of the off-chain and on-chain schemas is allowing the standardised definition of application specific token data[^1]. 
Standardization is important in order to set the grounds for interoperability between multiple chains, but also is flexibility. Unique Network sets the goal to support many standards to stay interoperable and at the same time flexible enough to accommodate new schema standards as they appear. Thus, the Network does not restrict the schema to any format, but allows to select the format out of existing known standards to the moment: ERC-721, OpenSea, or Tezos. The NFT wallets will be able to read the schema version that is stored on-chain and display the NFTs appropriately[^1]. 

### White Lists
Depending on the application design and requirements, the collection may be accessible for a wide audience or for a restricted and private group of accounts. In the latter case, a white list access mode may be enabled to restrict capabilities of owning and transferring tokens by only accounts included in the white list[^1].

### Private and Public Minting
The Collection owner may choose to allow non-privileged users to mint tokens in their collection by enabling the public minting mode. Combined with the White Lists, this could be a powerful tool for applications that require their users to be able to create their own tokens, such as art galleries, some games or applications for collectors[^1].

## Comparison of platforms

[Appendix](Appendix/Appendix.md "jump to the appendix")

---

# Solution

Having more features in a system shows that it has a competitive advantage. Because of the use of underlying layers of Unique There are a lot of features to the proposed work. Every layer injects features into another layer. So, the properties of every layer are inheritable. MFS use the unique parachain as the settlement layer.

## Core Business

`Business Areas`
-   Music production, artist management & marketing, record label management, copyright control

`Music Business`
-   Album, digital music, concerts & performances, events, advertising, merchandising, royalty management, auction

`Media Production`
-   Concert production & operation, playlist, fandom channel

> The Successful Factor of Entertainment Business:

`Artists`
-   Need a competitive celebrity with talent

`Marketing & Plan`
-   Frequent exposure on partnerships of platform, the press, social media, and other media
-   Create albums to meet current music trends

`Producing`
-    Produce sound sources with high-quality and popular music preference.

`Fandom`
-   Form a fandom culture that can increase the artist’s brand awareness.
-   Encourage fans to spread the message that ‘the artist is popular.

## Actors 

- [x] Singers
- [x] Songwriters 
- [x] Record labels
- [x] Publishers 
- [x] Artist managers
- [x] Digital content creators 
- [x] Web2.0 accounts

## Building a relationship between artists and fans
A&R mint a podcast or singer practices what it promotes and issues free NFTs to its fans as a way to reward its loyal listeners, grow its audience and generate excitement. Issue free NFTs to get new listeners to make a ripple effect.

## Progress Phases

### Initiating

- [x] Support rights and intellectual properties.
- [x] Read helpers and FAQ section of the platform.

### [Planning]

- [x] Making a plan by A&R (single producer doesn't need this step)
- [x] DAO A&R-oriented
  
### Executing

1. Record & producing by a singer, [mixer & masters], [LCL] of the platform.
2. Making a plan by A&R
3. Mint free NFTs
4. [Presale]
5. Mint track/album NFT

### Monitoring and controlling

1. Filter & Search
2. Promotion
3. Management
4. Monitor

### Closing

- [x] Transfer NFTs to wallet
- [x] Fandom channel
- [x] DAO investment-oriented
- [x] Utilizing actors' earnings are determined in some way by the defi mechanisms of the platform.


## Proposed Architecture

<figure markdown>
![Architecture](./assets/architecture.JPG){ width="800" height="600" align=center }
<figcaption>Fig 2. Proposed Architecture</figcaption>
</figure>

## Sovereign and governance
Decide how to keep safe actors in a long-term sustainable way.

### DAO & Governance Tokens
Allowing collective ownership & decision making of proposed protocol. Only governance token holders can submit and vote on protocol governance.
We offer a decentralized autonomous organization([DAO](./DAO/DAO.md)) rather than a corporate governance model.
Using only a whitelisted strategy is not enough, and implementing a credential strategy would help with staking as a hybrid governance model. Mitigating the issues with token governance is possible.

### Delegation
token holders may delegate their voting power to more active/informed users. So, this may not exacerbate plutocracy. Because every delegation deserves to active users but not users deactivate.

### Non-token governance
Proof of humanity (one person, one vote), proof of participation, and proof of contribution have been proposed. Each comes with its own method.

### Accountability
Making voters accountable for the consequences of their actions by imposing penalties and rewards based on the outcome.
  
### Voting Governance Model
Governance token holders can delegate their tokens to others (who do not even need to hold GT) to vote.Proposed platform will have the capability to propose (submit MFS Improvement Proposals, or MIPs) and vote.Participants must lock up their MFS (MFS DAO's governance token could called vote escrowed MFS/veMFS) by transferring them from their private wallets(On Polkadot known controller account) to the voting contract (from where they can be later withdrawn). MFS holders can lock their tokens so they can obtain veMFS in order to gain voting and proposal making powers. There is voting power minimum, but a user must have veMFS to create a proposal.

---


## Safe digital assets in a long-term sustainable way
The frontend UI hosted on IPFS. It consists of several pages powered by ReactJS. There is an integrate with NFT Chain by means of Polkado{.js} browser extension, metamask and PolkadotJS API.
DApp supports Web3 wallets so users can lend and borrow founds directly through their UI.
Unique and Polkadot.js are easy-to-use wallet that are perfect for non-technical audiences who are storing assets, who love our white-label solution.

## Collection

- [x] MusicPunks NFT collection created in NFT Pallet with 1000 minted NFTs. Each NFT has the MFS ID and on-chain properties that determine the look of the character.
      
- [x] Matcher smart contract that stores current market state and matches incoming bids from the UI against existing ask offers. This contract is written with Rust.

### Management
It is hard to overestimate the importance of Ownership in human society. Ownership defines the exclusive rights and control over the property. Thus property, ownership, and rights are one of the most important mankind essentials. It is important for one’s solid realization of the universe to build a correct and precise model of ownership and rights.
Another important right that collection ownership gives is [administrator](Collection_Management/administrator.md) who is would be labeler. An administrator of collection is the account that has elevated privileges over common users, but slightly less than a collection owner. As such, only the collection owner can destroy the collection and add administrators. This permission level was mainly aimed to allow automated operations over collections, such as minting tokens on demand. Also, a [smart contract](/Smart_Contract/smartcontract.md) can serve as a collection administrator to allow advanced decentralized application logic such as Claiming free [MusicPunks](/Collection_of_App/MusicPunk.md)


## Mint the NFTs
MFS flexes the sustainability known with underlying Unique framework— a NPOS network with a much lower carbon footprint than Ethereum. You can mint NFTs without worrying about impacting the environment, and focus more on your finished product. Unleash your creativity, build the next-gen NFT ecosystems in a way that are climate friendly!
the NFT pallet allows storing the NFT metadata in order to allow more authentic definitions of NFT items, while staying agnostic of this metadata format. The Substrate framework provides a robust and flexible WebSocket API allowing connections to the Blockchain to be established by its clients: NFT wallets, Marketplaces, and other programs.
On MFS DApp, creating NFT collections is easy, free, and secure, without ever needing to write a single line of code! We give you the option to mint any digital asset, and both owners and administrators can manage collections.
Burn MFS token-> Mint NFT

## Marketplace
The type of the marketplace is a crypto native curated marketplaces that require contributors to be approved to create NFTs and sell them on the platform. Similar to the open marketplaces, they require cryptocurrencies for payment, and have consumers custody the assets themselves.
You don’t need to have deep blockchain knowledge to understand, build and enjoy our NFT, which allows for the safe and trustless exchange of NFT or RFT assets, sponsored transaction fees, subscriptions, and scheduled transactions.

## Fan Governance and Decision-Making
NFTs can be used to enable fans to impact decisions and outcomes of the albums or a specific concert. labelers are starting to explore NFT assets that grant fans certain permissions, such as voting rights for team decisions, the ability to compete in events and leaderboards, and earning MFS rewards and VIP experiences linked to their teams.

## Ticketing
In addition to being collectables, NFTs can be combined with event tickets to provide access to an event. These tickets can provide verifiable authenticity, provide royalties upon secondary sales or auctions, and even turn digital tickets into unique commemorative assets.

## Playlist
Whether you’re showcasing past drops or highlighting your newest NFTs, the customization options and new tech integrations give you the option to choose how your visitors will view your work. 

## Properties
#### Private and Public Minting
DApp has inherited only public minting and creating an optional whitelist for actors to make limitations based on location, genres, sex, and age.

---

## The next phase of digitizing art assets

### Benefits
- [x] Ease of use. Tokens are trivially created, stored, traded
- [x] Fractional Ownership. Think of the prohibitively expensive music track in the concert or NFTs such as MusicPunks.
- [x] Tokenization allows investors to own fractions of the asset. Accessibility. Again, think of the volume of transactions in music market or physically distributed, versus the volume of transactions in NFTs or crypto.
- [x] Market efficiency. Tokenization may smooth out boom-and-bust cycles of illiquid markets by making them more liquid and organized.

### Challenges
- [x] Generally, not decentralized: intermediaries will ALWAYS be needed for non-native assets.
- [x] Legal recognition


## Tokenization

### MFS Token Benefits
The goal of MFS Token is to become a cryptocurrency that can be used in various ways, including defi, concerts, events, and every kind of future purchases. The MFS looks forward to achieving this vision with unique apps and token plan that make a huge difference in token trading and distribution. MFS Token enables music and album sales in the new market through instant payment and Blockchain-based streaming service as well as promotions, and it will bring innovation to the market. To achieve this vision, the MFS will promote the project through various media and continue steady marketing activities.

## Sponsoring scenario
Artists need to produce/promote their work, go on tour. Financing options are limited with loans (Debt).

1.  Alice(as labeler or A&R) is a promising musician,songwriter or a singer at her early famous stages.
2.  She needs $100,000 for equipment, practice, training, traveling to go local concert.
3.  She signs up at the platform, builds her profile, signs a smart contract with the platform and then 100,000 tokens (each valued at $1) are issued.
4.  Tokens are sold to investors. Alice receives $100K, while investors get the rights to 30% of her future income for a fixed period.
5.  Alice invests the funds on professional practicing and participation in events around the world.
6.  After a few years, Alice has developed into a professional player earning $300,000 a year.
7.  Of this income, 30% (i.e. $90K annually) is distributed to token holders via the NFT platform.
8.  Investors receive income (dividends) and can sell tokens, which will fluctuate in value according to income/maturity.

### Overview of Token Valuation
Think of tokens like a stock, which builds value from…

- [x] Dividends
- [x] Buybacks
- [x] Price appreciation
- [x] Size of the market
- [x] Number of tokens
- [x] Momentum and price dynamics

### Token distribution

<figure markdown>
![Token distribution](./assets/token-distribution.JPG){ width="600" height="600" align=center }
<figcaption>Fig 3. MFS Token distribution</figcaption>
</figure>


## Deal with digital assets in a long-term sustainable way
### Liquidity Provider (LP) Tokens
LP tokens represent shares in liquidity pools, used in decentralized exchanges.
### The MFS Staking
The MFS Staking Hub has made it easy for users to [stake](/DEFI/stake.md) and unstake [UNQ](/DEFI/unq.md)  and [MFS](/DEFI/MFS.md)  tokens, supporting the development of the MFS decentralized application. By betting their tokens, users can earn rewards while contributing to the growth of the blockchain. The staking program offers a percent of APY, generated through inflation and funded by the MFS Treasury.
Additionally, the application allows users to grow their capital while sponsoring dApp transactions and supporting the MFS application. With partial unstaking, users can easily manage their funds, providing better liquidity access.

### Enabling NFT Exchanges and Auctions
There are usually three different types of auctions to choose from:
1. Reserve auction: An auction where interested buyers can only make bids equal to or higher than your reserve price. 
2. Scheduled auction: A timed auction has specific start and end times. It’s an ideal option to sell a piece quickly or during a particular event.  
3. Unlimited auction: In this case, interested buyers bid until you accept one.


## Platform Infrastructure Costs
Operating a proprietary marketplace rather than leveraging an existing marketplace can provide additional control over the assets, where the files are stored, and how they are consumed, but comes with additional costs. In addition to marketplace sale or auction fees and transaction costs, there are other infrastructure costs like payment acceptance and custody.
The NFT marketplace charge a fee when sales or auctions occur on the application, usually ranging between 1% to 3% while there is fee 5% in so many NFT platforms.


## Store and access NFTs securely and easily
Distribute across an applicable marketplace.The Cryptopunks project was developed by Larva Labs in 2017, then a two-person team of Canadian software developers who took inspiration from the cyberpunk movement, edgy electronic music, and films about a dystopian, technological future like Blade Runner. This project was also an inspiration for the ERC-721 standard, becoming a framework on the blockchain for the birth and continual growth of non-fungible tokens. We believe that [MusicPunks](/Collection/Collection_of_App/MusicPunk.md) will be the best case study for Unique NFT capabilities. We’re equally excited to deploy additional advanced features for NFTs.
The iconic Cryptopunks, one of the first ever NFTs. Also released in a collection of 10,000 (four years prior in 2017), Cryptopunks helped set the scene for the immense energy of the burgeoning NFT community.
As of writing, the lowest price available to pick up a Cryptopunk of your own is almost 81.99 ETH ($280.52K) and rare punks are selling for upwards of $10,000,000.
If you're going to publish an NFT collection, why not kick it off with a moment that truly flexes the platform's power and gives users a taste of what to expect from the future? Say hello to [Chelomusic](./Collection_of_App/Chelomusic.md).
Chelomusics are a collection of 1000 NFTs, built on (Unique)[Unique/Unique.md], that will be going live on our Marketplace over time. Not only was this drop a significant milestone to showcase how our product allows creators to build on [Polkadot](/Polkadot/polkadot.md), but it was an early look into our dedication to building a new kind of efficient community on the blockchain.
The Unique-based Chelomusic Collection saw most of the 1000 MFS, randomly generated, characters (e.g genres, types of mixes). This sale will have welcomed a variety of new users to Polkadot and shows them NFTs on this network can shake some of the constraints that many users face running on ETH (slow network speeds, limited feature set, lack of scalability).
For Chelomusics holders, one could say owners and buyers sensed that they were a part of another historic moment for digital collectibles — the NFTs available on Unique. Who wouldn't want to hold one of the next Cryptopunks?

---

## Our Proposed unique platform - The Trusted Engine of Commerce

> What makes MFS so special?

### NFT EEC

#### Unique moments or elements from a particular song or album
#### Unlock exclusive experiences related to a particular artist or band

### Music LCL

<figure markdown>
![Sample produce of Live code](assets/sample-audio1.JPG){ width="600" height="400" align=center }
<figcaption>Fig 4. Sample live code-Generate sounds</figcaption>
</figure>

### NFT minor ownership

---

# Miscellanea And Concerns

## Exit Strategy
Exit! Exit! Exit! Our innovation ecosystems are focused on this goal above all else, thanks to the reliance on venture capital. Young potential entrepreneurs talk about exit strategies before even creating an innovation or starting a business. Our innovation ecosystems push them to do so in many ways. Seemingly straightforward questions to budding entrepreneurs such as “What is your exit strategy?” drastically shift focus and outcomes away from creating long–term societally beneficial innovations. We argue that this hypergrowth exit mindset is destroying societal wellbeing due to its laser focus on increasing socially constructed exit value above all else[^14]. 

## Risk Management
Many NFTs have high monetary value and given their exchange velocity (digital assets can be exchanged much more quickly than physical assets), there is opportunity for fraudulent activity. To minimize this risk, NFT platforms should leverage KYC and AML procedures, as well as security best practices like two-factor authentication[^6].

## Licensing and T&Cs
It is important to be clear what rights are bestowed to owners of the NFTs, and whether these are the same or separate from the rights associated with the material object the NFT refers to. These terms are generally provided contractually in Terms and Conditions from the creator or the ecosystem operator’s platform rules. Brands with strong IP generally retain all the rights, allowing very limited rights for personal use, while newer crypto-native projects may provide owners greater commercial rights[^6].

## Copyright Control
Due to NFTs are new, there is limited legal and regulatory clarity on how existing laws may apply. Laws that may be implicated include contract, property rights, intellectual property, sweepstakes/promotions, privacy, and securities laws. Furthermore, adding to the complexity, since blockchains operate across jurisdictions, transactions involving NFTs can implicate laws outside the United States. Lawmakers, regulators, and courts are still in the process of evaluating how to treat NFTs under existing laws, and whether new laws are needed to protect collectors, artists, and other participants in the NFT ecosystem. Accordingly, it is highly recommended that businesses consult an attorney that has the relevant subject matter expertise. Due to the regulatory uncertainty, there is risk in any transaction involving NFTs. So,[copyright control](Copyright_Control/Copyright_Control.md) is really important[^6].

## AI

[AI](AI/AI.md) music generator outputs potentially infringe the rights of music copyright holders. Specifically, by up-sampling copyrighted works in finely encoded segments[^17].
Under English copyright law, works generated by AI, can theoretically be protected as works "generated by computer in circumstances such that there is no human author of the work".Under UK law, it is not clear which of the fixed categories of copyright 'works' would protect a voice[^18].

This moment presents an opportunity for technology companies and the music industry to avoid repeating past mistakes by addressing this new disruptive technology as partners, rather than opponents[^17].

Characterizing the AI generator’s output as “original” is misleading, because doing so disregards the role that reproduction of copyrighted works plays in generating the sample. Accordingly, we must assess whether the mechanics of machine-learning music generators can be reconciled with the protections afforded creative authors under the Copyright Act[^17].

One of the latest innovations in AI technology is deepfake vocal synthesisers which make a singer's voice sound like a famous artist or even tools which create a wholly synthetic voice[^18].
When a track by artist "Ghostwriter" was uploaded and then promptly removed from streaming services in April, it was the latest example of one of 2023's most astonishing trends. The track 'heart on my sleeve' sounded like it was sung by two of the world's biggest stars, Drake and The Weeknd. In fact, it was actually someone who had used an AI tool to make his voice sound like theirs[^18].

---

# Overview of the team

The MFS team has extensive experience across all relevant sectors - from e-commerce, to cryptocurrency, marketing, blockchain, music production, and web application. Crucially, the team has ”done this before”, and possesses all the experience needed to realize MFS.

<figure markdown>
![MFS Chart](assets/mfs-chart.JPG){ width="600" height="400" align=center }
<figcaption>Fig 5. MFS HR-Chart</figcaption>
</figure>


> [Arman Riazi, Co-Founder & CTO](https://armanriazi.github.io)

- [x] Over 12 years experience in software engineer
- [x] Over 4 year experience in Web3
- [x] Broad experience of startups and within e-commerce
- [x] Extensive background in web development
- [x] Active blockchain researcher and mentor
- [x] Solutions architect within distributed/decentralized computing
- [x] MSc, Information Technology

> Shahab Kamal, Web Developer 

> Kianoush Dorta, Web Developer 



---

# Roadmap
The research and development in MFS will be a continuous process with a result of miscellaneous PoCs and further implementation in MainNet or ecosystem tools in case if the corresponding research project succeeds. Advertising and inviting famous artists are parallel tasks during the season.

[Appendix](Appendix/Appendix.md "jump to the appendix")

<figure markdown>
![New intermediaries needed for all non-native assets](./assets/token-pillar.JPG){ width="600" height="400" align=center }
<figcaption>Fig 6. Finance stack[15]</figcaption>
</figure>

## 3Q 2023
- [x] Market analysis and Research
- [x] Project planning
- [x] White and yellow paper
- [ ] Private fund-rising
- [ ] Team up
- [ ] Relocating to settle down 
- [ ] Providing infrastructure for remote working

## 4Q 2023
- [ ] Release of MFS DApp Marketplace
- [ ] Music Distribution

## 1Q 2024
- [ ] Playlist
- [ ] Supporting music streaming, downloading service
- [ ] Launching LCL service
- [ ] Tokenization, Presale
- [ ] Royalty management

## 2Q 2024
- [ ] Record label management
- [ ] Launching DEFI stacking program

## 3Q 2024
- [ ] DAO
- [ ] Auction
- [ ] Copyright control

## 4Q 2024
- [ ] Launching EEC service
- [ ] Data Analytics
- [ ] Maximize services and token utilization

## 1Q 2025
- [ ] Supporting token payment service by mobile APP
- [ ] Release of MFS Mobile DApp Marketplace

---

# Future work

MFSgotchi

---

# Conclusion
Commerce is evolving, and innovations such as crypto and NFTs are likely to shape entertainment, and other communities going forward. NFTs represent a deeper and more innovative way for fans to engage and potential new revenue streams for organizations. However, there are many considerations to take into account when integrating NFTs because it is a new space.
MFS Platform provisioned an engaging and immersive NFT music appreciation experience are endless. Leveraged the unique qualities of NFTs to create engaging experiences that connect fans with the music they love in new and exciting ways.
Risks in our apps can stem from protocol or unique network.Also, failures poor governance by the time proposed work will become a DAO governance.

---

> Further Reading:

> The paper is a summary of the main paper. So, for joining our community or making a contribution to our proposed work, it would be great to [fill out the form for contributors](forms/Form_partnership.md). We will send you an invitation link, and then we will have a meeting to find out your purpose or approach. Finally, you will gain access to the main resources and new ideas of the MFS NFT platform.

[DApp](https://MFS.app)

[MFS](https://armanriazi.github.com/mfs)

[Author](https://armanriazi.github.io)

> List of Abbreviations

A&R Artists and repertoire |

DAPP Decentralized application |

NFT non-fungible token |

RFT Re-fungible token |

ReFi Regenerative Finance |

LP Liquidity Provider |

LCL Live coding language

EEC Exclusive experience content

POS Proof-of-stake |

UNQ Unique Token |

BG blockchain governance

M2E Music-To-Earn

MFS (Name of DApp-till register company)


---

# References

[six reference]: Disabled means it has been excluded from the whitepaper but not the full version of the main paper.

[^1]: [Unique Network Technical Paper](https://github.com/UniqueNetwork/techpaper/blob/master/unique_techpaper.pdf)

[^2]: Unchained Music. (n.d.). Unchainedmusic.Io. Retrieved June 5, 2023, from https://unchainedmusic.io/

[^3]: [Brother Music Platform Token Whitepaper](https://bmpbrave.com/BMP%20WhitePaper_ENG.pdf)

[^4]: Invest in music. (n.d.). Royal.Io. Retrieved June 5, 2023, from https://royal.io/

[^6]: [Visa NFT Whitepaper](https://usa.visa.com/content/dam/VCOM/regional/na/us/Solutions/documents/visa-nft-whitepaper.pdf)

[^8]: [Smart Contracts: 12 Use Cases for Business & Beyond](https://github.com/bellaj/Blockchain/blob/master/Smart%20Contracts%20-%2012%20Use%20Cases%20for%20Business%20and%20Beyond%20-%20Chamber%20of%20Digital%20Commerce.pdf)

[^10]: Hewa, T. M., Hu, Y., Liyanage, M., Kanhare, S. S., & Ylianttila, M. (2021). Survey on blockchain-based smart contracts: Technical aspects and future research. IEEE Access: Practical Innovations, Open Solutions, 9, 87643–87662. https://doi.org/gn8f8x

[^14]: Lam, L., & Seidel, M.-D. L. (2020). Hypergrowth exit mindset: Destroying societal wellbeing through venture capital biased social construction of value. Journal of Management Inquiry, 29(4), 471–474. https://doi.org/ghf56f

[^15]: Li, X., Wang, Z., Leung, V. C. M., Ji, H., Liu, Y., & Zhang, H. (2022). Blockchain-empowered data-driven networks: A survey and outlook. ACM Computing Surveys, 54(3), 1–38. https://doi.org/kcn9

[^16]: Belchior, R., Vasconcelos, A., Guerreiro, S., & Correia, M. (2020). A survey on blockchain interoperability: Past, present, and future trends. https://doi.org/kcpp

[^17]: Sunray, E. (2021). Sounds of science: Copyright infringement in AI music generator outputs. Catholic University Journal of Law and Technology, 29(2), 185–218. https://scholarship.law.edu/jlt/vol29/iss2/9/

[^18]: AI-generated music and copyright. (n.d.). Clifford Chance. Retrieved May 30, 2023, from https://www.cliffordchance.com/insights/resources/blogs/talking-tech/en/articles/2023/04/ai-generated-music-and-copyright.html

[^19]: van Pelt, R., Jansen, S., Baars, D., & Overbeek, S. (2021). Defining blockchain governance: A framework for analysis and comparison. Information Systems Management, 38(1), 21–41. https://doi.org/gm2m6b

[^20]: Gavin, W. (2016). Whitepaper [Polkadot.network/whitepaper](https://polkadot.network/whitepaper/)






















