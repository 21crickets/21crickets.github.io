---
keywords:  MFS ArmanRiazi Music NFT Blockchain career employment
feature:  manifesto
author: "Arman Riazi"
title: "Manifesto"
---

> NOTICE OF CONFIDENTIALITY([Terms and Conditions](Concern_Legal/Agreement_Legal.md))
Case studies, comparisons, statistics, research, and recommendations are provided “AS IS” and intended for informational purposes only and should not be relied upon for operational, marketing, legal, technical, tax, financial, or other advice. AramisTech . neither makes any warranty or representation as to the completeness or accuracy of the information within this document, nor assumes any liability or responsibility that may result from reliance on such information. The Information contained herein is not intended as investment or legal advice, and readers are encouraged to seek the advice of a competent professional where such advice is required. All of details of papers were registered. The paper that you are reading is not a final version, so it is possible that some sections will have minor changes.

> MFS is the short name of the platform, and it is going to be  mentioned  in the final version of the paper.

### Overview of Token Valuation
Think of tokens like a stock, which builds value from…

- [x] Dividends
- [x] Buybacks
- [x] Price appreciation
- [x] Size of the market
- [x] Number of tokens
- [x] Momentum and price dynamics

<figure markdown>
![Token distribution](../assets/token-distribution.JPG){ width="600" height="600" align=center }
<figcaption> MFS Token distribution </figcaption>
</figure>

# Overview of the team
AramisTech is trying register its business as a private limited company. We are an IT services and web 3.0 company. We specialize in providing development solutions to startups and development.
The MFS team must have extensive experience across all relevant sectors - from e-commerce, to cryptocurrency, marketing, blockchain, music production, and web application. Crucially, the team would has ”done this before”, and possesses all the experience needed to realize MFS.

<figure markdown>
![MFS Chart](../assets/mfs-chart.JPG){ width="600" height="400" align=center }
<figcaption>Fig 9. MFS HR-Chart</figcaption>
</figure>

We have some bench resources for immediate onboarding or a preferred relocation in the near future.

---

> Setting up a new business without a doubt, an exciting endeavor. This could bring all of us a lot of great things in the future.

> The paper is a summary of the main paper. So, for joining our community or making a contribution to our proposed work, it would be great to [fill out the form for contributors](../forms/Form_job_application.md) or [LinkedIn company page](https://www.linkedin.com/company/aramistech). We will send you an invitation link, and then we will have a meeting to find out your purpose or approach. Finally, you will gain access to the main resources and new ideas of the MFS NFT platform.

Our team is skilled and dedicated to providing top-notch services. If you're interested in working with us, please let us know. We would be happy to discuss you.


Best regards,

Arman Riazi