---
keywords:  MFS ArmanRiazi Music NFT Blockchain seed Manifesto venture capital
feature:  paper
author: "Arman Riazi"
title: "Manifesto for"
---

- [Partnerships](manifesto_for_partnerships.md)

- [Employments](manifesto_for_employment.md)

