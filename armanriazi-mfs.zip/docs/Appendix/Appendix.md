<figure markdown>
![Architecture](../assets/comparison-platforms-main.JPG){align=center }
<figcaption>Fig. Proposed Architecture</figcaption>
</figure>

<figure markdown>
![Architecture](../assets/comparison-platforms-2.JPG){align=center }
<figcaption>Fig. Proposed Architecture</figcaption>
</figure>