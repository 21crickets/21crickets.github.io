

<a href="https://www.producthunt.com/posts/mfs-a-nft-music-platform?utm_source=badge-featured&utm_medium=badge&utm_souce=badge-mfs&#0045;a&#0045;nft&#0045;music&#0045;platform" target="_blank"><img src="https://api.producthunt.com/widgets/embed-image/v1/featured.svg?post_id=398779&theme=light" alt="MFS&#0058;&#0032;A&#0032;NFT&#0032;Music&#0032;Platform - nft&#0032;music&#0032;blockchain&#0032;smartcontract&#0032;polkadot&#0032;unique | Product Hunt" style="width: 250px; height: 54px;" width="250" height="54" /></a>

[![FOSSA Status](https://app.fossa.com/api/projects/git%2Bgithub.com%2Farmanriazi%2Fmfs.svg?type=large)](https://app.fossa.com/projects/git%2Bgithub.com%2Farmanriazi%2Fmfs?ref=badge_large)

[On zenodo community](https://zenodo.org/communities/aramistech-mfs)