# My ToDo List


> Solution->Fee
Unique Network is going to offer several gas fee models for its users in order to provide as much flexibility as possible to adapt to miscellaneous marketing strategies of application developers and remove UX friction for the newcomers.
The gas fee model is configured separately for each Collection or a smart contract. Every Collection and smart contract has a fee model assigned to it, which determines how its transactions are paid, and the developer can choose the fee model that better suits their application[^1].


> Is admin is an labeler?

knowledge Graph NFT





